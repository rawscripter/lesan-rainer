<?php $__env->startSection('content'); ?>

    <style>
        .page-heading {
            margin: 20px 0;
            color: #666;
            -webkit-font-smoothing: antialiased;
            font-family: "Segoe UI Light", "Arial", serif;
            font-weight: 600;
            letter-spacing: 0.05em;
        }

        #my-dropzone .message {
            font-family: "Segoe UI Light", "Arial", serif;
            font-weight: 600;
            color: #0087F7;
            font-size: 1.5em;
            letter-spacing: 0.05em;
        }

        .dropzone {
            border: 2px dashed #0087F7;
            background: white;
            border-radius: 5px;
            min-height: 300px;
            padding: 90px 0;
            vertical-align: baseline;
        }
    </style>
    <div class="content-wrapper">
        <div class="page-header">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Upload New Image</li>
                </ol>
            </nav>
        </div>
        <div class="card">
            <div class="card-body">

                <?php if(Session::has('message')): ?>
                    <div class="row">
                        <div class="col-md-12 m-auto">
                            <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12 mt-5 mb-5">
                        <h4>Drag And Drop Images</h4>
                        <form action="<?php echo e(route('admin.upload.image')); ?>" class="dropzone d-flex align-items-center"
                              id="my-awesome-dropzone">
                            <?php echo e(csrf_field()); ?>

                        </form>

                    </div>
                </div>
                <div class="text-center mt5">
                    <span class="btn btn-primary"><a href="<?php echo e(route('admin.uploads')); ?>">Go Back</a></span>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lesan\rainer\resources\views/admin/images/upload.blade.php ENDPATH**/ ?>