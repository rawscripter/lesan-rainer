<?php $__env->startSection('body'); ?>
	<
	<div class="main_content">
		<div class="row m-0 p-0">
			<div class="col-md-6 offset-md-3 col-lg-6 offset-lg-3">
				<div class="collection text-center">
					<h1>INSTALLATIONS</h1>
				</div>
			</div>
		</div>
		<!-- start demo modal -->
		
		
		<!-- end of modal -->
		<div class="colection_content">
			<div class="container">
				<div class="installation-area-btn text-center">
					<a href="<?php echo e(route('site.installations')); ?>" class="btn btn-light mt-3  rounded-0" style="min-width: 150px;">SHOW
						ALL</a>
					<a href="?filter=Private" class="btn btn-outline-light mt-3  rounded-0" style="min-width: 150px;">PRIVATE</a>
					<a href="?filter=Public" class="btn btn-outline-light mt-3  rounded-0" style="min-width: 150px;">PUBLIC</a>
				</div>
				
				<div class="infinite-scroll">
					<div class="row m-0 p-0">
						<?php $__currentLoopData = $installations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4 col-lg-4">
								<div class="collection_single">
									<div class="collection_image">
										<img width="100%" src="/images/feature/<?php echo e($ins->image_1); ?>" alt="collection-image">
										<div class="collection_shadow callInstallationDetailsModal" data-installation="<?php echo e($ins->id); ?>">
											<h5>
												<p>click to view
													details</p>
											</h5>
										</div>
									</div>
									<a href="#"><h3><?php echo e($ins->name); ?></h3></a>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						<?php echo e($installations->appends($_GET)->links()); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	<div id="callBackModal">
	
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<script type="text/javascript">

      $('ul.pagination').hide();
      $(function () {
          $('.infinite-scroll').jscroll({
              autoTrigger: true,
              padding: 0,
              nextSelector: '.pagination li.active + li a',
              contentSelector: 'div.infinite-scroll',
              callback: function () {
                  $('ul.pagination').remove();
              }
          });
      });
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lesan\rainer\resources\views/site/inststallations.blade.php ENDPATH**/ ?>