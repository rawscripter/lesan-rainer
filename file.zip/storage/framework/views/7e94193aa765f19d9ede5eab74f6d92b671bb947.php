<?php $__env->startSection('head'); ?>
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">
		<div class="page-header">
			<nav aria-label="breadcrumb">
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a></li>
					<li class="breadcrumb-item active" aria-current="page">All Installations</li>
				</ol>
			</nav>
		</div>
		<div class="card">
			<div class="card-body">
				
				<?php if(Session::has('message')): ?>
					<div class="row">
						<div class="col-md-12 m-auto">
							<p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
						</div>
					</div>
				<?php endif; ?>
				
				
				<div class="row">
					<div class="col-12">
						<div class="create-btn text-right">
							<a href="<?php echo e(route('installations.create')); ?>"
							   class="btn btn-primary">Add New Installation</a><br>
						</div>
					</div>
					<div class="col-12 mt-5">
						
						<div id="order-listing_wrapper"
						     class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
							<table class="table  no-footer" role="grid"
							       aria-describedby="order-listing_info">
								<thead>
								<tr role="row">
									<th>Sl.</th>
									<th>Name</th>
									<th>Location</th>
									<th>Art</th>
									<th>Edit</th>
									<th>Delete</th>
								</tr>
								</thead>
								<tbody>
								<?php
									$i = 1;
								?>
								<?php $__currentLoopData = $installations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($i++); ?></td>
										<td><?php echo e($ins->name); ?></td>
										<td><?php echo e($ins->location); ?></td>
										<td><?php echo e($ins->art->name); ?></td>
										<td>
											<a href="<?php echo e(route('installations.edit',$ins->id)); ?>"
											   class="btn btn-primary">
												Edit
											</a>
										</td>
										<td>
											<form method="POST"
											      action="<?php echo e(route('installations.destroy',$ins->id)); ?>">
												<?php echo e(csrf_field()); ?>

												<?php echo e(method_field('DELETE')); ?>

												<input onClick="return confirm('Are you sure you want to delete the Installation?')"
												       type="submit" class="btn btn-danger"
												       value="Delete">
											</form>
										</td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
	<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
	
	<script>
      $(document).ready(function () {
          $('table').DataTable({
              "order": [[0, "desc"]]
          });
      });
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lesan\rainer\resources\views/admin/installtion/index.blade.php ENDPATH**/ ?>