<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
    <style>
        .table td img, .jsgrid .jsgrid-table td img {
            width: 120px;
            height: auto !important;
        }

        .lightGallery .image-tile img {
            max-width: 100%;
            width: 120px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="page-header">
            <h3 class="page-title">
                Uploads table
            </h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active" aria-current="page">All Uploads</li>
                </ol>
            </nav>
        </div>
        <div class="card">
            <div class="card-body">

                <?php if(Session::has('message')): ?>
                    <div class="row">
                        <div class="col-md-12 m-auto">
                            <p class="alert alert-success"><?php echo e(Session::get('message')); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="row">
                    <div class="col-12">
                        <div class="create-btn text-right mb-5">
                            <a href="<?php echo e(route('admin.upload.image.page')); ?>"
                               class="btn btn-primary">Upload New Images</a><br>
                        </div>
                        <div class="card mt5">
                            <table class="table table-striped table-borderless">
                                <tr>
                                    <th>
                                        Image
                                    </th>

                                    <th>
                                        Image Name
                                    </th>

                                    <th>
                                        Active
                                    </th>
                                </tr>
                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="card-body">
                                                <div class="row lightgalleryID lightGallery">
                                                    <a href="/images/arts/<?php echo e($img->name); ?>" class="image-tile">
                                                        <img src="/images/thumb/<?php echo e($img->name); ?>" alt="image small">
                                                    </a>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <?php echo e($img->name); ?>

                                        </td>

                                        <td>
                                            <form method="POST"
                                                  action="<?php echo e(route('admin.upload.image.delete',$img->id)); ?>">
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('DELETE')); ?>

                                                <input onClick="return confirm('Are you sure you want to delete the Image?')"
                                                       type="submit" class="btn btn-danger"
                                                       value="Delete">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('assets/admin/js/dropify.js')); ?>"></script>

    <script>
        $(document).ready(function () {
            $('table').DataTable({
                "order": [[0, "desc"]]
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lesan\rainer\resources\views/admin/images/index.blade.php ENDPATH**/ ?>