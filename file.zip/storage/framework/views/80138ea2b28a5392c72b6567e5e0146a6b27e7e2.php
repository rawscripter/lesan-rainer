<?php $__env->startSection('content'); ?>

    <style>
        .card.card-statistics {
            background: linear-gradient(85deg, #06b76b, #f5a623);
            color: #ffffff;
        }
    </style>
    <div class="main-panel" style="width: 100% !important;">
        <div class="content-wrapper">
            <div class="page-header">
                <h3 class="page-title">
                    Dashboards
                </h3>
            </div>
            <div class="row grid-margin">
                <div class="col-12">
                    <div class="card card-statistics">
                        <div class="card-body">
                            <div class="d-flex flex-column flex-md-row align-items-center justify-content-between">

                                <div class="statistics-item">
                                    <p>
                                        <i class="icon-sm fab fa-trello menu-icon mr-2"></i>
                                        Collections
                                    </p>
                                    <h2><?php echo e($collections); ?></h2>
                                </div>
                                <div class="statistics-item">
                                    <p>
                                        <i class="icon-sm fab fa-wpforms menu-icon mr-2"></i>
                                        Art Works
                                    </p>
                                    <h2><?php echo e($activeArts); ?></h2>

                                </div>
                                <div class="statistics-item">
                                    <p>
                                        <i class="icon-sm fas fa-hourglass-half mr-2"></i>
                                        Archive Arts
                                    </p>
                                    <h2><?php echo e($archiveArts); ?></h2>

                                </div>

                                <div class="statistics-item">
                                    <p>
                                        <i class="icon-sm fas fa-users mr-2"></i>
                                        Visitors
                                    </p>
                                    <h2><?php echo e($visitors); ?></h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Recent Activities</h4>
                            <div class="mt-5">
                                <div class="timeline">

                                    <?php
                                        $i = 1;
                                    ?>
                                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="timeline-wrapper <?php echo e($i % 2 == 0 ? 'timeline-inverted timeline-wrapper-warning' : 'timeline-wrapper-success'); ?> ">
                                            <div class="timeline-badge"></div>
                                            <div class="timeline-panel">
                                                <div class="timeline-heading">
                                                    <h6 class="timeline-title"><b><?php echo e($log->title); ?></b></h6>
                                                </div>
                                                <div class="timeline-body">
                                                    <p>
                                                        <?php echo e($log->body); ?>

                                                    </p>
                                                </div>
                                                <div class="timeline-footer d-flex align-items-center">
                                                    <span class="ml-auto font-weight-bold"><?php echo e($log->created_at->diffForHumans()); ?></span>
                                                </div>
                                            </div>
                                        </div>

                                        <?php
                                            $i++;
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="view-all-logs text-center">
                                <a href="<?php echo e(route('admin.logs')); ?>" class="btn btn-default text-success">View All Logs</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <!-- partial -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lesan\rainer\resources\views/admin/index.blade.php ENDPATH**/ ?>