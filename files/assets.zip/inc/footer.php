	<div id="scroll_up"></div>
	<footer class="footer_area">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-6">
					<div class="footer_copyrigth_sec">
						<p>Copyright &copy; <?php echo date('Y'); ?> RainerLagemann.com</p>
					</div>
				</div>
				<div class="col-md-6 col-lg-6">
					<div class="footer_designer_info">
						<p>Website by <a href="#" style="color: #c7c7c7;text-decoration: none;">Tride Designs</a></p>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<script src="//code.jquery.com/jquery-3.4.1.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
	<script src="//stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<script src="assets/js/main.js"></script>
	</body>

	</html>