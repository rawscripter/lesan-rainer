<?php require_once 'inc/header.php'; ?>
<div class="main_content">
	<div class="row m-0 p-0">
		<div class="col-md-6 offset-md-3 col-lg-6 offset-lg-3">
		<div class="collection text-center">
			<h1>DANCERS</h1>
		</div>
	</div>
	</div>
<!-- start demo modal -->



	<!-- end of modal -->
	<div class="colection_content">
		<div class="container">
			<div class="row m-0 p-0">
				
				<div class="col-md-4 col-lg-4">
					<div class="collection_single">
						<div class="collection_image">
							<img width="100%" src="assets/images/collcetion/gallery-2-500x500 - Copy.jpg" alt="collection-image">
						</div>

						<a href="#"><h3>Art name</h3></a>
						
					</div>
				</div>	

				<div class="col-md-4 col-lg-4">
					<div class="collection_single">
						<div class="collection_image">
							<img width="100%" src="assets/images/collcetion/gallery-2-500x500 - Copy.jpg" alt="collection-image">
						</div>

						<a href="#"><h3>Art name</h3></a>
						
					</div>
				</div>		
			<div class="col-md-4 col-lg-4">
					<div class="collection_single">
						<div class="collection_image">
							<img width="100%" src="assets/images/collcetion/gallery-2-500x500 - Copy.jpg" alt="collection-image">
						</div>

						<a href="#"><h3>Art name</h3></a>
						
					</div>
				</div>	
			<div class="col-md-4 col-lg-4">
					<div class="collection_single">
						<div class="collection_image">
							<img width="100%" src="assets/images/collcetion/gallery-2-500x500 - Copy.jpg" alt="collection-image">
						</div>

						<a href="#"><h3>Art name</h3></a>
						
					</div>
				</div>
				<div class="col-md-4 col-lg-4">
					<div class="collection_single">
						<div class="collection_image">
							<img width="100%" src="assets/images/collcetion/gallery-2-500x500 - Copy.jpg" alt="collection-image">
						</div>

						<a href="#"><h3>Art name</h3></a>
						
					</div>
				</div>

			</div>
			<div class="form-group text-center">
				<a href="#"  class="btn btn-light mt-3  rounded-0" style="min-width: 150px;">Load more</a>
			</div>
		</div>
	</div>
</div>
<?php require_once 'inc/footer.php'; ?>