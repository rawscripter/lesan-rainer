<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArtCollection extends Model
{
    protected $fillable = ['art_id', 'collection_id'];

}
