<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ArtImage extends Model
{
    protected $guarded = [];

}
